# logestic-regression-
this a project to find the predict the flower specied based on Iris-setosa', 'Iris-versicolor', 'Iris-virginica
